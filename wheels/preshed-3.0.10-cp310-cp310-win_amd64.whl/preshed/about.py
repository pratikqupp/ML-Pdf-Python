__title__ = "preshed"
__version__ = "3.0.10"
__summary__ = "Cython hash table that trusts the keys are pre-hashed"
__uri__ = "https://github.com/explosion/preshed"
__author__ = "Explosion"
__email__ = "contact@explosion.ai"
__license__ = "MIT"
__release__ = True
